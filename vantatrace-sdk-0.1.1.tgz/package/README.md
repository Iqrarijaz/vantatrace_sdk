# VantaTrace Node.js SDK

VantaTrace SDK is a lightweight, zero-overhead exception tracking and telemetry client for server-side Node.js applications and Express.js APIs. It intercepts uncaught errors, captures unhandled promise rejections, gathers host/runtime contexts, and streams normalized telemetry payloads asynchronously to your VantaTrace central ingestion server.

## Installation

Install the client package via npm:
```bash
npm install @vantatrace/sdk
```

## Quick Start

### 1. Initialization
Initialize the VantaTrace client at the top of your application entrypoint:

```javascript
import { VantaTrace } from '@vantatrace/sdk';

const vantaTrace = new VantaTrace({
  apiKey: 'YOUR_PROJECT_API_KEY', // Obtain from VantaTrace Admin Console
  serviceName: 'order-service',    // Name of your microservice
  environment: 'live',             // 'live' or 'test'. Auto-inferred from API key prefix if   debug: false                     // Set to true to print SDK internal diagnostics
});
```

### 2. Auto-capture Global Exceptions
To automatically intercept uncaught exceptions and unhandled promise rejections before the Node process exits:

```javascript
vantaTrace.initGlobalHandlers();
```

### 3. Express.js Error Handler Middleware
To log exceptions raised in Express request handlers and routes, mount the middleware at the bottom of your route definitions:

```javascript
import express from 'express';
const app = express();

// ... Define routes and controller endpoints ...
app.get('/checkout', (req, res) => {
  throw new Error('Payment gateway timeout');
});

// The VantaTrace middleware MUST be registered after all route definitions,
// but before other custom express error handling middlewares:
app.use(vantaTrace.expressMiddleware());

app.use((err, req, res, next) => {
  res.status(500).send('Internal Server Error');
});
```

### 4. Manual Exception Capturing
To manually trace handled exceptions, assign custom contextual parameters, or specify severity:

```javascript
try {
  // perform some actions
} catch (error) {
  vantaTrace.captureException(error, {
    userId: 'user_8872',
    route: '/api/v1/orders',
    method: 'POST',
    severity: 'warning', // optional: 'critical', 'warning', or 'info'
    metadata: {
      orderId: 'ord_128d9a',
      amount: 149.50
    }
  });
}
```

#### Severity Shortcuts
You can also use dedicated helper methods to automatically assign severity:

```javascript
// Capture a critical system failure
vantaTrace.captureCritical(error, { userId: 'user_8872' });

// Capture a warning
vantaTrace.captureWarning(error);

// Capture general information / handled failures
vantaTrace.captureInfo(error);
```

## Features

- **Reference Normalization**: Safe serialization of deep call stacks, native errors, and custom properties.
- **Asynchronous Delivery**: Telemetry reporting runs asynchronously to ensure it never blocks thread execution or delays HTTP responses.
- **Auto-Redaction**: Middleware automatically filters out sensitive body parameters (`password`, `token`) and HTTP header keys (`Cookie`, `Authorization`, `x-api-key`) from collected logs.
- **Host & System Telemetry**: Captures host platform hostname, Node runtime version, PID, CPU architecture, platform type, CPU load averages (`loadavg`), and process uptime automatically.
- **Memory Tracking**: Auto-captures heap totals, heap usage, external memory footprint, and system-wide free/total RAM during exception triggers.
- **Error Attributes Extraction**: Captures standard error code fields (`err.code`), HTTP statuses (`err.status`/`err.statusCode`), and any custom enumerable metadata attached to the exception.
- **Request Context Enrichment**: Express middleware captures client IP address and sanitized headers to assist debugging.